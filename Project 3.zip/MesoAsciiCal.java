
public class MesoAsciiCal extends MesoAsciiAbstract 
{
   
}