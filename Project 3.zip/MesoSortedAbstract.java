import java.util.HashMap;
import java.util.Map;

public abstract class MesoSortedAbstract
{
	abstract Map<String, Integer> sortedMap(HashMap<String, Integer> unsorted);
}
