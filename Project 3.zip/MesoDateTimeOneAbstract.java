public abstract class MesoDateTimeOneAbstract
{
	abstract int getValueOfSecond();
	abstract void dateTimeNow();
	abstract void sleepForFiveSec();
	abstract void dateTimeOfOtherCity();
	abstract void dateTimeDifferentZone();
	abstract void timeZoneHashMap();
}